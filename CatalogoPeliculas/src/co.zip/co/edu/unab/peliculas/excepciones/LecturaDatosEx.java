package co.edu.unab.peliculas.excepciones;

public class LecturaDatosEx extends AccesoDatosEx{
    public LecturaDatosEx(String mensaje){
        super(mensaje);
    }
}
