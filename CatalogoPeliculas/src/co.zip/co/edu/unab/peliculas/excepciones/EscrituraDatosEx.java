package co.edu.unab.peliculas.excepciones;

public class EscrituraDatosEx extends AccesoDatosEx {
    public EscrituraDatosEx(String mensaje){
        super(mensaje);
    }
}
